from PyQt5 import QtWidgets
from pantallasPy.consultarStock import consultarStockHerramientas

class ConsultarStockHerramientas(QtWidgets.QWidget,consultarStockHerramientas.Ui_Form):
    def __init__(self, *args, **kwargs):
        QtWidgets.QWidget.__init__(self, *args, **kwargs)
        self.setupUi(self)
        self.he_btn_buscar.clicked.connect(self.buscarArticulo)

    def buscarArticulo(self):
        self.valor1 = self.he_input_buscar.text()

        print(self.valor1)





if __name__ == "__main__":
    app = QtWidgets.QApplication([])
    window = consultarStockHerramientas()
    window.show()
    app.exec_()