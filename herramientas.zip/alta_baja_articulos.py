from PyQt5 import QtWidgets
from pantallasPy.altabajaDeArticulos import altaBajaArticulosHerramientasOption
from pantallasPy.altabajaDeArticulos import altaDeArticulosHerramientas
from pantallasPy.altabajaDeArticulos import bajaDeArticulosHerramientas
from abm import ABM


class AltaArticulos(QtWidgets.QWidget,altaDeArticulosHerramientas.Ui_Form):
    def __init__(self, *args, **kwargs):
        QtWidgets.QWidget.__init__(self, *args, **kwargs)
        self.setupUi(self)
        self.he_btn_confirmar.clicked.connect(self.alta)


    def alta(self):
        self.value1 = self.he_input_1.text()
        self.value2 = self.he_input_2.text()
        self.value3 = self.he_input_3.text()
        self.value4 = self.he_input_4.text()
        self.value5 = self.he_input_5.date().toPyDate().strftime("%Y/%m/%d")
        self.value6 = self.he_input_6.toPlainText()

        #campos = ('codigo','cantidad','cantidad_max','cantidad_min','fecha','descripcion')
        #tupla_datos = (self.value1,self.value2,self.value3,self.value4,self.value5,self.value6)
        #print(tupla_datos)
        #abm = ABM.ABM()
        #abm.alta('articulos_herramientas',campos,tupla_datos)


class BajaArticulos(QtWidgets.QMainWindow,bajaDeArticulosHerramientas.Ui_Form):
    def __init__(self, *args, **kwargs):
        QtWidgets.QMainWindow.__init__(self, *args, **kwargs)
        self.setupUi(self)
        self.he_btn_confirmar.clicked.connect(self.baja)

    def baja(self):
        self.value1 = self.he_input_1.text()
        self.value2 = self.he_input_2.toPlainText()

        print(self.value1,self.value2)


class MenuArticulos(QtWidgets.QWidget,altaBajaArticulosHerramientasOption.Ui_Form):
    def __init__(self, *args, **kwargs):
        QtWidgets.QWidget.__init__(self, *args, **kwargs)
        self.setupUi(self)
        self.he_btn_1.clicked.connect(self.alta)
        self.he_btn_2.clicked.connect(self.baja)

    def alta(self):
        self.window = AltaArticulos()
        self.window.show()

    def baja(self):
        self.window = BajaArticulos()
        self.window.show()


if __name__ == "__main__":
    app = QtWidgets.QApplication([])
    window = MenuArticulos()
    window.show()
    app.exec_()