#import mysql.connector

class ABM():
    def __init__(self):
        self.conexion = mysql.connector.connect(user = 'root',password = '',host = 'localhost',database = 'capsi_srl')
        self.cursor = self.conexion.cursor()

    def alta(self,tabla,campos,valores):
        self.tabla = tabla
        self.valores = valores
        self.campos = ''
        self.items = ''
        if(len(campos) > 0):
            for c in campos:
                self.campos += c + ','
        if(len(valores) > 0):
            for v in valores:
                self.items += ' %s,'
        self.sql = 'INSERT INTO ' + self.tabla + '(' + self.campos[:-1] + ')' + 'VALUES' + '(' + self.items[:-1] + ')'
        self.cursor.execute(self.sql,self.valores)
        self.conexion.commit()
        print(self.cursor.rowcount,'insertado correctamente')
        self.cursor.close()

    def baja(self,tabla,campo,valor):
        self.tabla = tabla
        self.valor = valor
        self.campo = campo
        self.sql = 'DELETE FROM ' + self.tabla + ' WHERE ' + self.campo + ' = ' + self.valor
        self.cursor.execute(self.sql)
        self.conexion.commit()
        print(self.cursor.rowcount,'eliminado correctamente')
        self.cursor.close()

    def consulta(self,tabla,campos,campo,valor):
        self.tabla = tabla
        self.campos = ''
        self.campo = campo
        self.valor = valor
        self.sql = 'SELECT '
        if(self.campos == '*'):
            self.sql += self.campos + ' FROM ' + self.tabla
            if(self.campo != ''):
                self.sql += ' WHERE ' + self.campo + ' = ' + self.valor
                print(self.sql)
            else:
                print(self.sql)
        else:
            if(len(self.campos) > 0):
                for c in self.campos:

                    print(self.sql)
        #print(len(self.campo))
    #def consulta(self,tabla,identificacion):

    #def modificacion(self):




#abm = ABM()
#v = ('codigo','fecha','descripcion')
#ºº= ('24452452','2010/09/05','Lorem ')
#abm.baja('articulos_herramientas','id_articulo','11')
#abm.alta('articulos_herramientas',v,t)
#abm.consulta('articulos_herramientas',v,'id','25')

#query = 'INSERT INTO articulos_herramientas(codigo,cantidad,cantidad_max,cantidad_min,fecha,descripcion) VALUES (%s, %s, %s, %s, %s, %s)'
