from PyQt5 import QtWidgets
from pantallasPy import sectorHerramientas
import alta_baja_articulos
import consultar_stock_herramientas
import estado_articulo
import maxima_minima_stock
import modificar_stock
import stock_por_movil
import stock_por_tecnico

class SectorHerramientas(QtWidgets.QWidget,sectorHerramientas.Ui_Form):
    def __init__(self, *args, **kwargs):
        QtWidgets.QWidget.__init__(self, *args, **kwargs)
        self.setupUi(self)
        self.he_btn_1.clicked.connect(self.menuConsultarStockHerramientas)
        self.he_btn_2.clicked.connect(self.menuModificarStock)
        self.he_btn_3.clicked.connect(self.menuAltaBajaArticulos)
        self.he_btn_4.clicked.connect(self.menuMaximoMinimoStock)
        self.he_btn_5.clicked.connect(self.menuStockMovil)
        self.he_btn_6.clicked.connect(self.menuStockTecnico)
        self.he_btn_7.clicked.connect(self.menuEstadoArticulo)

    def menuConsultarStockHerramientas(self):
        self.window = consultar_stock_herramientas.ConsultarStockHerramientas()
        self.window.show()

    def menuModificarStock(self):
        self.window = modificar_stock.ModificacionStockHerramientas()
        self.window.show()

    def menuAltaBajaArticulos(self):
        self.window = alta_baja_articulos.MenuArticulos()
        self.window.show()

    def menuMaximoMinimoStock(self):
        self.window = maxima_minima_stock.ModificacionMaxMin()
        self.window.show()

    def menuStockMovil(self):
        self.window = stock_por_movil.StockPorMovilHerramientas()
        self.window.show()

    def menuStockTecnico(self):
        self.window = stock_por_tecnico.StockPorTecnico()
        self.window.show()

    def menuEstadoArticulo(self):
        self.window = estado_articulo.EstadoArticuloHerramientas()
        self.window.show()


if __name__ == "__main__":
    app = QtWidgets.QApplication([])
    window = SectorHerramientas()
    window.show()
    app.exec_()
