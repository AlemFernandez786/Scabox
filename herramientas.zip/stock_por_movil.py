from PyQt5 import QtWidgets
from pantallasPy.stockPorMovil import stockPorMovilHerramientas

class StockPorMovilHerramientas(QtWidgets.QWidget,stockPorMovilHerramientas.Ui_Form):
    def __init__(self, *args, **kwargs):
        QtWidgets.QWidget.__init__(self, *args, **kwargs)
        self.setupUi(self)
        self.he_btn_confirmar.clicked.connect(self.cambiarStock)

    def cambiarStock(self):
        self.value1 = self.he_input_1.text()
        self.label1 = self.he_label_2.setText(self.value1)
        print(self.value1)

if __name__ == "__main__":
    app = QtWidgets.QApplication([])
    window = StockPorMovilHerramientas()
    window.show()
    app.exec_()
