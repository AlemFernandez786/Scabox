from PyQt5 import QtWidgets
from pantallasPy.modificacionMaxMin import modificacionMaxMin

class ModificacionMaxMin(QtWidgets.QWidget,modificacionMaxMin.Ui_Form):
    def __init__(self, *args, **kwargs):
        QtWidgets.QWidget.__init__(self, *args, **kwargs)
        self.setupUi(self)
        self.he_btn_confirmar.clicked.connect(self.modificarMaxMin)

    def modificarMaxMin(self):
        self.value1 = self.he_input_1.text()
        self.value2 = self.he_input_2.text()
        self.value3 = self.he_input_3.text()
        self.value4 = self.he_input_4.text()

        print(self.value1,self.value2,self.value3,self.value4)


if __name__ == "__main__":
    app = QtWidgets.QApplication([])
    window = ModificacionMaxMin()
    window.show()
    app.exec_()