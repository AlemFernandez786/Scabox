from PyQt5 import QtWidgets
from pantallasPy.estadoDeArticulo import alertEstadoArticuloHerramientas
from pantallasPy.estadoDeArticulo import estadoArticuloHerramientas

class AlertEstadoArticuloHerramientas(QtWidgets.QWidget,alertEstadoArticuloHerramientas.Ui_Form):
    def __init__(self, *args, **kwargs):
        QtWidgets.QWidget.__init__(self, *args, **kwargs)
        self.setupUi(self)


class EstadoArticuloHerramientas(QtWidgets.QWidget,estadoArticuloHerramientas.Ui_Form):
    def __init__(self, *args, **kwargs):
        QtWidgets.QWidget.__init__(self, *args, **kwargs)
        self.setupUi(self)
        self.he_btn_buscar.clicked.connect(self.buscarArticulo)
        self.he_btn_estado.clicked.connect(self.cambiarEstado)


    def buscarArticulo(self):
        self.valor1 = self.he_input_buscar.text()
        print(self.valor1)

    def cambiarEstado(self):
        self.window = AlertEstadoArticuloHerramientas()
        self.window.show()


if __name__ == "__main__":
    app = QtWidgets.QApplication([])
    window = EstadoArticuloHerramientas()
    window.show()
    app.exec_()