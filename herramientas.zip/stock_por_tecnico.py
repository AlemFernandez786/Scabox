from PyQt5 import QtWidgets
from pantallasPy.stockPorTecnico import mensajeDevolucionEntrega
from pantallasPy.stockPorTecnico import stockPorTecnico


class MensajeDevolucionEntrega(QtWidgets.QWidget,mensajeDevolucionEntrega.Ui_Form):
    def __init__(self, *args, **kwargs):
        QtWidgets.QWidget.__init__(self, *args, **kwargs)
        self.setupUi(self)
        self.he_radiobutton_1.toggled.connect(self.seleccion)
        self.he_radiobutton_2.toggled.connect(self.seleccion)
        self.he_btn_confirmar.clicked.connect(self.devolucionOentrega)

    def seleccion(self):
        self.b = self.sender()
        if self.b.isChecked():
            self.resultado = self.b.text()


    def devolucionOentrega(self):
        print(self.resultado)



class StockPorTecnico(QtWidgets.QWidget,stockPorTecnico.Ui_Form):
    def __init__(self, *args, **kwargs):
        QtWidgets.QWidget.__init__(self, *args, **kwargs)
        self.setupUi(self)
        self.he_btn_confirmar.clicked.connect(self.mensaje)

    def mensaje(self):
        #self.value1 = self.he_input_1.text()
        self.window = MensajeDevolucionEntrega()
        self.window.show()


if __name__ == "__main__":
    app = QtWidgets.QApplication([])
    window = StockPorTecnico()
    window.show()
    app.exec_()
