from PyQt5 import QtWidgets
from pantallasPy.modificacionStock import modificacionDeStockHerramientas


class ModificacionStockHerramientas(QtWidgets.QWidget,modificacionDeStockHerramientas.Ui_Form):
    def __init__(self, *args, **kwargs):
        QtWidgets.QWidget.__init__(self, *args, **kwargs)
        self.setupUi(self)
        self.he_btn_buscar.clicked.connect(self.buscarHerramientas)
        self.he_btn_confirmar.clicked.connect(self.modificarStock)

    def buscarHerramientas(self):
        self.value1 = self.he_input_buscar.text()
        print(self.value1)

    def modificarStock(self):
        self.value1 = self.he_input_1.text()
        self.value2 = self.he_input_2.text()
        self.value3 = self.he_input_3.text()
        self.value4 = self.he_input_4.toPlainText()
        print(self.value1,self.value2,self.value3,self.value4)



if __name__ == "__main__":
    app = QtWidgets.QApplication([])
    window = ModificacionStockHerramientas()
    window.show()
    app.exec_()
